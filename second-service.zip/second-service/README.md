# Centime First service

2nd Service) It contains one get method which is called by the first service to fetch a string”Hello” wrapped with a spring response entity.