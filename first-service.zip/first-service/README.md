# Centime First service

1st Service) Expose two http methods, one get and one post (add swaggerUI).
From the get method return “Up” if service is up. The post method should return the concatenated responses of the Get call of Service 2 and the Post call of Service 3 using the same payload({The json})
